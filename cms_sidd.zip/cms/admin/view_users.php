
<table class="table table-bordered table-hover">
  <thead class="thead-light">
    <tr>
      
      <th>user_id</th>
      <th>username</th>
       
        <th>user_firstname</th>
         <th>user_lastname</th>
          <th>user_email</th>
          <th>user_image</th>
          <th>user_role</th>
          <th>user_status</th>
    </tr>
  </thead>
  <tbody>
    <tr>

         <?php

                                        $query = "SELECT * FROM users";
                                        $select_all_users = mysqli_query($connection,$query);
                                       
                                       while ($row = mysqli_fetch_assoc($select_all_users)) {
                                           $user_id = $row['user_id'];
                                            $username = $row['username'];
                                            
                                              $user_firstname = $row['user_firstname'];
                                              $user_lastname = $row['user_lastname'];
                                              $user_email = $row['user_email'];
                                                $user_image = $row['user_image'];
                                                $user_role = $row['user_role'];
                                                $user_status = $row['user_status'];
                                          

echo "<td>{$user_id}</td>";
echo "<td>{$username}</td>";

echo "<td>{$user_firstname}</td>";
echo "<td>{$user_lastname}</td>";
echo "<td>{$user_email}</td>";
echo "<td><img class='img-responsive' width = '100' src='../images/{$user_image}'></td>";
echo "<td>{$user_role}</td>";
echo "<td>{$user_status}</td>";



echo "<td><a href='users.php?approve={$user_id}'>App</a></td>";
echo "<td><a href='users.php?unapprove={$user_id}'>Unapp</a></td>";
echo "<td><a href='users.php?source=edit_users&u_id={$user_id}'>edit</a></td>";
echo "<td><a href='users.php?delete={$user_id}'>delete</a></td>";

echo "</tr>";


}
 ?>

<?php 
  if (isset($_GET['unapprove'])) {
    $user_status = $_GET['unapprove'];

    $query = "UPDATE users SET user_status = 'unapproved' WHERE user_id = $user_status";
    $user_post = mysqli_query($connection,$query);
    header("Location: users.php");
}
 ?>
 <?php 
  if (isset($_GET['approve'])) {
    $user_status = $_GET['approve'];

    $query = "UPDATE users SET user_status = 'approved' WHERE user_id = $user_status";
    $user_post = mysqli_query($connection,$query);
    header("Location: users.php");
}
 ?>








 <?php 
  if (isset($_GET['delete'])) {
    $the_user_id = $_GET['delete'];

    $query = "DELETE FROM users WHERE user_id = {$the_user_id}";
    $select_users = mysqli_query($connection,$query);
    header("Location: users.php");
}
 ?>

    </tr>
   
  </tbody>
</table>

