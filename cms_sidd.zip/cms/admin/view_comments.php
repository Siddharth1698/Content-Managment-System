
<table class="table table-bordered table-hover">
  <thead class="thead-light">
    <tr>
      
      <th>comment_id</th>
      <th>comment_post_id </th>
       <th>comment_author</th>
        <th>comment_email</th>
         <th>comment_content</th>
          <th>comment_status</th>
          <th>comment_date</th>
          
    </tr>
  </thead>
  <tbody>
    <tr>

         <?php

                                        $query = "SELECT * FROM comments";
                                        $select_all_comments = mysqli_query($connection,$query);
                                       
                                       while ($row = mysqli_fetch_assoc($select_all_comments)) {
                                           $comment_id = $row['comment_id'];
                                            $comment_post_id = $row['comment_post_id'];
                                             $comment_author = $row['comment_author'];
                                              $comment_email = $row['comment_email'];
                                              $comment_content= $row['comment_content'];
                                              $comment_status = $row['comment_status'];
                                                $comment_date = $row['comment_date'];
                                                
                                          

echo "<td>{$comment_id}</td>";
echo "<td>{$comment_post_id}</td>";
echo "<td>{$comment_author}</td>";
echo "<td>{$comment_email}</td>";
echo "<td>{$comment_content}</td>";
echo "<td>{$comment_status}</td>";
echo "<td>{$comment_date}</td>";
echo "<td><a href='comments.php?approve={$comment_id}'>App</a></td>";
echo "<td><a href='comments.php?unapprove={$comment_id}'>Unapp</a></td>";
echo "<td><a href='comments.php?delete={$comment_id}'>del</a></td>";


echo "</tr>";


}
 ?>

 <?php 
  if (isset($_GET['unapprove'])) {
    $comment_status = $_GET['unapprove'];

    $query = "UPDATE comments SET comment_status = 'unapproved' WHERE comment_id = $comment_status";
    $comment_post = mysqli_query($connection,$query);
    header("Location: comments.php");
}
 ?>
 <?php 
  if (isset($_GET['approve'])) {
    $comment_status = $_GET['approve'];

    $query = "UPDATE comments SET comment_status = 'approved' WHERE comment_id = $comment_status";
    $comment_post = mysqli_query($connection,$query);
    header("Location: comments.php");
}
 ?>

    <?php
 $query = "UPDATE posts SET  post_comment_count =  post_comment_count + 1 ";
 $select_comments = mysqli_query($connection,$query);

                                        ?>







 <?php 
  if (isset($_GET['delete'])) {
    $the_comment_id = $_GET['delete'];

    $query = "DELETE FROM comments WHERE comment_id = {$the_comment_id}";
    $comment_post = mysqli_query($connection,$query);
    header("Location: comments.php");
}
 ?>

    </tr>
   
  </tbody>
</table>

