 
   <?php  session_start();
             include "includes/header.php";
             include "includes/db.php";
             
   
    ?>


<div id="wrapper">

        <!-- Navigation -->


        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
            
                <!-- /.row -->
<h1> <?php echo $_SESSION['username']; ?> </h1>
<?php 
    if (isset($_SESSION['username'])) {
      $username = $_SESSION['username'];

      $query = "SELECT * FROM users WHERE username = '{$username}'";
      $connec = mysqli_query($connection,$query);

        while ($row = mysqli_fetch_array($connec)) {
                                            $user_id = $row['user_id'];
                                            $username = $row['username'];
                                             $user_password = $row['user_password'];
                                              $user_firstname = $row['user_firstname'];
                                             
                                              $user_image = $row['user_image'];
                                                $user_lastname = $row['user_lastname'];
                                                $user_email = $row['user_email'];
                                                $user_role = $row['user_role'];
        }







    }




 ?>




<div class="form-group">
  <label for="username">username</label>
  <input value="<?php  if(isset($username)) {echo $username;} ?>" type="text" class="form-control" name="username">

</div>
<div class="form-group">
  <label for="user_password">user_password</label>
  <input value="<?php  if(isset($user_password)) {echo $user_password;} ?>" type="password" class="form-control" name="user_password">
</div>
<div class="form-group">
  <label for="user_firstname">user_firstname</label>
  <input value="<?php  if(isset($user_firstname)) {echo $user_firstname;} ?>" type="text" class="form-control" name="user_firstname">
</div>

<div class="form-group">
  <img width="300" height="300" src=" ../images/<?php echo $user_image; ?> " >
  <input value="<?php  if(isset($user_image)) {echo $user_image;} ?>" type="file" class="form-control" name="user_image">
</div>
<div class="form-group">
  <label for="user_lastname">user_lastname</label>
  <input value="<?php  if(isset($user_lastname)) {echo $user_lastname;} ?>" type="text" class="form-control" name="user_lastname">
</div>
<div class="form-group">
  <label for="user_email">user_email</label>
  <input value="<?php  if(isset($user_email )) {echo $user_email ;} ?>" type="text" class="form-control" name="user_email">
</div>

<div class="form-group">
  <label for="user_role">user_role</label>
  <input value="<?php  if(isset($user_role)) {echo $user_role;} ?>" type="text" class="form-control" name="user_role">
</div>





 <?php 
             include "includes/navigation.php";
   
    ?>
 


</div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

 <?php 
             include "includes/footer.php";
   
    ?>